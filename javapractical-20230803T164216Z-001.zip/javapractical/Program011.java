import java.util.*;//FIND OUT AMONTH USING A NUMBER
class Program011
{
		static void run(int n)
		{
				String l= new String();
				if(n==0)l="JAN";
				else if(n==1)l="FEB";
				else if(n==2)l="MARCH";
				else if(n==3)l="APRIL";
				else if(n==04)l="MAY";	
				else if(n==5)l="JUNE";
				else if(n==06)l="JULY";
				else if(n==07)l="AUG";
				else if(n==8)l="SEP";
				else if(n==9)l="OCT";
				else if(n==10)l="NOV";
				else if(n==11)l="DEC";
				if(n>11 || n<0)
				System.out.println("invalid number");
				else
				System.out.println("the MONTH is    "+l);
				


		}
		public static void main(String args[])
		{
			
			Scanner s=new Scanner(System.in);
			System.out.println("enter an number of the day(0-11)   ");
			 int n=s.nextInt();
			run(n);
			
		}	
}