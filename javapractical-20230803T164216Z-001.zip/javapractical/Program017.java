 import java.util.*;//the largest among 3 numbers
class Program017
{
		public static void main(String args[])
		{
			
			Scanner s=new Scanner(System.in);
			System.out.println("enter any 3 numbers");
			int  a=s.nextInt();
			int  b=s.nextInt();
			int  c=s.nextInt();
			int max=0;
			max=((a>b) && (a>c))?a:((b>a) && (b>c))?b:((c>a) &&  (c>b))?c:a;
			System.out.println("the largest among 3 numbers is  "+max);
	        }

}