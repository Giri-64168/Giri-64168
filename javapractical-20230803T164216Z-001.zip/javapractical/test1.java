import java.util.*;
class test
{
	private int day;
	private int month;
	private int year;
	
	public void  set_day(int d)
	{
		day=d;
		
	}
	public int get_day()
	{
		return day;
		
	}
		public void  set_month(int m)
	{
		month=m;
		
	}
	public int get_month()
	{
		return month;
		
	}
		public void  set_year(int y)
	{
		year=y;
		
	}
	public int get_year()
	{
		return year;
		
	}
}	
	
class test1
{
	public static void main(String args[])
	{
		
		Scanner s=new Scanner(System.in);
		test t=new test();
		System.out.println("enter the day(0-6)");
		int d=s.nextInt();
		System.out.println("enter the month (0-12)");
		int m=s.nextInt();
		System.out.println("enter the year");
		int y=s.nextInt();
		t.get_day();
		t.get_month();
		t.get_year();
		System.out.println(d+"-"+m+"-"+y);
	}
}