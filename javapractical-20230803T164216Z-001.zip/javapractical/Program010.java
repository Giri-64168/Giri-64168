import java.util.*;
class Program010
{
		static void run(int n)
		{
				String l= new String();
				if(n==0)l="sunday";
				else if(n==1)l="monday";
				else if(n==2)l="tuesday";
				else if(n==3)l="wednesday";
				else if(n==04)l="thursday";	
				else if(n==5)l="friday";
				else if(n==06)l="saturday";	
				if(n>7 || n<0)
				System.out.println("invalid number");
				else
				System.out.println("the day is    "+l);
				


		}
		public static void main(String args[])
		{
			
			Scanner s=new Scanner(System.in);
			System.out.println("enter an number of the day(0-6)   ");
			 int n=s.nextInt();
			run(n);
			
		}	
}