import java.util.*;//perimeter of the circle
class Program014
{
		static double run(double r)
		{
			return (2*(Math.PI)*r);
		}
		public static void main(String args[])
		{
			
			Scanner s=new Scanner(System.in);
			System.out.println("enter the radius  ");
			double  r=s.nextDouble();
			System.out.println("perimeter of the circle is  "+run(r));
		}	
		
}