import java.util.*;
  class area_of_triangle
{
		public static void main(String args[] )
		{
			double n,m,a_o_t;
			Scanner s=new Scanner(System.in);
			System.out.println("enter base of the triangle");
			n=s.nextDouble();
			System.out.println("enter the height of the triangle");
			m=s.nextDouble();
			a_o_t=((1.0/2.0)*n*m);
			System.out.println("the area of the triangle is "+a_o_t);
			
		}
}