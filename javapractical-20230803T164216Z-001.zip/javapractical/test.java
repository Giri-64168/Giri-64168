import java.util.Scanner;
  class point
{
	private double x;
	private double y;
	public double getx()
	{
		return this.x;
	}
	public double gety()
	{
		return this.y;
	}
	
	point()
	{
		x=0;
		y=0;
	}
		
		point(double x1,double y1)
		{
			x=x1;
			y=y1;
		}
		public double distance_from_origin()
		{
                    double dist;
			dist=Math.sqrt(x*x+y*y);
			return dist;
			
		}
			public double distance_from_point(point q)
			{
				double diff_x=x-q.x;
				double diff_y=y-q.x;
				return Math.sqrt(diff_x*diff_x+diff_y*diff_y);
			}
		
		public void translate(double x_trans,double y_trans)
		{
			x=x+x_trans;
			y=y+y_trans;
		}
		
}
class test 
{
		public static void main(String args[])
		{
			Scanner s=new Scanner(System.in);
			System.out.println("enter the a1 value");
			double a1=s.nextDouble();
			System.out.println("enter the b1 value");
			double b1=s.nextDouble();
			point p=new point(a1,b1);
			System.out.println("the co ordinate values before translation is "+p.getx()+","+p.gety());
			
			//double res=p.distance_from_origin();
			System.out.println("enter the a2 value");
			double a2=s.nextDouble();
			System.out.println("enter the b2 value");
			double b2=s.nextDouble();
			point q=new point(a2,b2);
			p.translate(a2,b2);
			System.out.println("the co ordinate values after translation is "+p.getx()+","+p.gety());
			//double res1=p.distance_from_point(q);
			//point p1=new point();
			//double res=p1.distance_from_origin();
			//System.out.println("distance from the origin is "+res);
			//System.out.println("distance between points p and q is "+res1);
				
		}
}