import java.util.*;
class pattern2
{
		static void onerow(char ch,int nc)
		{
			for(int i=0;i<nc;i++)
			{
				System.out.print(ch);
				
			}
				System.out.println(" ");
		}
		static void printpattern(int nr,char ch)
		{
			for(int i=1;i<=nr;i++)
				{
				onerow(ch,i);
			
				}
			
		}
		public static void main(String args[ ])
		{		
			printpattern(6,'$');
			
		}
}