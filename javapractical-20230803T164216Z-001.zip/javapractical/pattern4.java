import java.util.*;
class pattern4
{
		static void onerow(char ch,int nc)
		{
			for(int i=0;i<nc;i++)
			{
				System.out.print(ch);
				
			}
				System.out.println(" ");
		}
		static void printpattern(int nr,char ch)
		{
			for(int i=nr;i>0;i--)
				{
				onerow(ch,i);
			
				}
			
		}
		public static void main(String args[ ])
		{		
			printpattern(6,'$');
			
		}
}