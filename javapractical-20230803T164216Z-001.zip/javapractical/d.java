public class address
{
	String city,state,country;
	public address(String city,String state, String country)
	{
		this.city=city;
		this.state=state;
		this.country=country;	
	}
}
class Emp
{
	int id;
	String name;
	adress add;
	public Emp(int id,String name,address add)
	{
		this.name=name;
		this.id=id;
		this.add=add;
		
	}
	void display()
	{
	}
}
class d
{
	public static void main(String args[])
	{
		address add1=new address(""
	}
}