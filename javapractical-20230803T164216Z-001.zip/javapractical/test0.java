class test0 
{
		public static void main(String args[])
		{
			Scanner s=new Scanner(System.in);
			System.out.println("enter the a value");
			double a=s.nextDouble();
			System.out.println("enter the b value");
			double b=s.nextDouble();
			point0 p3=new point0(a,b);
			double res=p3.distance_from_origin();
			System.out.println("distance from the origin is "+res);

				
		}
}