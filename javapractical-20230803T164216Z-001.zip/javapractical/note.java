getting compiled and run through different drive the syntax is 
c:\ javac d:\folder name\file name .java___compilation
c:\java   d:\folder name\ filename________run
with out using third number simple way to swap is
			a=(a+b)-(b=a)