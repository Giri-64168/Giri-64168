import java.util.*;//n print values using  for
class Print4
{
		public static void main(String args[ ])
		{
			
			Scanner s=new Scanner(System.in);
			for(int i=1;i<=10;--i)
			{
				System.out.println("hello"+i);
			}
		}
}