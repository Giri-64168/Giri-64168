import java.util.*;//largest among 3 numbers 
class Program015
{
		static int run(int n,int m,int l)
		{
			if(n>m && n>l)
			System.out.println(n+" is largest number");
			return n;	
		}
		static int display(int n,int m,int l)
		{
			if(m<n && m<l)
			System.out.println(m+" is smallest number ");
				return m;
			
		
		}
		public static void main(String args[])
		{
			
			Scanner s=new Scanner(System.in);
			System.out.println("enter any 3 numbers");
			int  n=s.nextInt();
			int  m=s.nextInt();
			int  l=s.nextInt();
			run(n,m,l);
			display(n,m,l);
	        }







}