import java.util.*;
class Program6
{
		public static void main(String args[])
		{
			char c;
			System.out.println("enter a character");
			Scanner s=new Scanner(System.in);
			c=s.next().charAt(0);
			if(c>=65 && c<=90)
			{
				System.out.println("upper");
				
			}
			else if(c>=97 && c<=122)
			{
				System.out.println("LOWER Case");
			}
			else if(c>=48 && c<=57)
			{
				System.out.println("number");
			
			}
			else
				System.out.println("symbol");
				
			
				
			
		}
}