import java.util.Scanner;//if else to find min of 3 numbers
class else_example2
{
		public static void main(String args[])
		{
			int i,j,k,min=0;
			Scanner s=new Scanner(System.in);
			System.out.println("eneter any 3 numbers to know the min");
			i=s.nextInt();
			j=s.nextInt();
			k=s.nextInt();
			if(i<j)
			{
				if(i<k) min=i;
				
			}		
			else if(j<i)
			{
				if(j<k) min=j ;
			}
			else
			min=k;
			System.out.println("the min of given 3 numbers is  "+min);
		}
}