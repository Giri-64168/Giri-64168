import java.util.*;
class Program04
{
	public static void main(String args [])
	{
		int n,m;
		Scanner s=new Scanner(System.in);
		System.out.println("eneter any two numbers");
		n=s.nextInt();
		m=s.nextInt();
		n=n+m;
		m=n-m;
		n=n-m;
		System.out.println("after swap first value become  "+n);
		System.out.println("after swap second value become  "+m);
	}
}