import java.util.Scanner;// to understand the scope of the variable
class Scope_example
{
		public static void main(String args[])
		{
			
			{
				int i=1;
				i++;
			System.out.println("this is a new block");
			System.out.println(i);
			}
			int i=10;
			int j=20;
			int k=i+j;
			System.out.println(k);
		
		}
}