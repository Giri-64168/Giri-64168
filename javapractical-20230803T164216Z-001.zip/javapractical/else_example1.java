import java.util.Scanner;//if else to understand
class else_example1
{
		public static void main(String args[])
		{
			int i,j;
			Scanner s=new Scanner(System.in);
			System.out.println("eneter any two numbers to be devide");
			i=s.nextInt();
			j=s.nextInt();
			if(j==0)
			System.out.println("divison by erroe");
			else 
			System.out.println(i/j);	
		}
}