import java.util.*;//print like helo1,helo2 like
class Print6
{
		public static void main(String args[ ])
		{
			
			Scanner s=new Scanner(System.in);
			for(byte i=1;i<=5;i++)
			{
				System.out.println("hello"+i);
			}
		}
}