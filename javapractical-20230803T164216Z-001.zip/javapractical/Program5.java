import java.util.*;
class Program5
{
			public static void main(String []args)
			{
				char c;
				System.out.println("enter a character");
				Scanner s=new Scanner(System.in);
				c=s.next().charAt(0);
				if((c>='a' && c<='z')||(c>='A' && c<='Z'))
				{
					System.out.println(c+" is alphabet");
				}
				else
				{		
					System.out.println(c+" is not an alphabet");
				}
				
			}
}