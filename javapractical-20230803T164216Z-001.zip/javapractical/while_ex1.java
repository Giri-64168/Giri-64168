import java.util.*;//while usage first it checks the condition
class while_ex1
{
		public static void main(String args[] )
		{
			Scanner s=new Scanner(System.in);
			int count=1;
			while(count<=10)
			{
				System.out.println("hii");
				count=count+1;
			}
		}
}
