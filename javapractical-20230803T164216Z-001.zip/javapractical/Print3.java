import java.util.*;//for using array
class Print3
{
		public static void main(String args[ ])
		{
			Scanner s=new Scanner(System.in);
			int[] numbers={3,7,5,-5};
			for(int number:numbers)
			{
				System.out.println(number);
			}
		}
}