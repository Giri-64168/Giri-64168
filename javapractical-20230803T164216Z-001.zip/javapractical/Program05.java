import java.util.*;
class Program05
{
		public static void main(String args[])
		{
			int n,m,temp;
			Scanner s=new Scanner(System.in);
			System.out.println("eneter two integers");
			n=s.nextInt();			
			m=s.nextInt();
			temp=n;
			n=m;
			m=temp;
			System.out.println("after swap the first value is  "+n);
			System.out.println("after swap the second value is  "+m);
		}
}