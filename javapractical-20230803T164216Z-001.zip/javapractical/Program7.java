import java.util.*;
class Program7
{

		public static void main(String [] args)
		{
				char c;
				Scanner s=new Scanner(System.in);
				c=s.next().charAt(0);
				int ascii=(int)c;
				System.out.println("ASCII VALUE OF THE GIVEN CHARACTER IS "+ascii);
		}	
}