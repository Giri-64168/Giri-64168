import java.util.*;//sum of entered integer along with previous numbers
class Print2
{
		public static void main(String args[ ])
		{
			int sum=0;
			int n;
			Scanner s=new Scanner(System.in);
			System.out.println("enter an integer");
			n=s.nextInt();
			for(int i=n;i>=1;--i)
			{
				sum+=i;
			}
			System.out.println("sum is  "+sum);
		}
}