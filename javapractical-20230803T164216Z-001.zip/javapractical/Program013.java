import java.util.*;//area of circle using radius
class Program013
{
		static double run(double r)
		{
			return Math.PI*r*r;
		}
		public static void main(String args[])
		{
			
			Scanner s=new Scanner(System.in);
			System.out.println("enter the radius  ");
			double  r=s.nextDouble();
			System.out.println("area of the circle is  "+run(r));	
		
	        }







}