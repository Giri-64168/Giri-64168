
import java.util.*;
 public class Program01
{
	 static  void run(int n)
	{
		if(n>0)
		
			System.out.println(n+" is possitive integer");
		
		else
		
			System.out.println(n+" is negetive integer");
		
	}
	public static void main(String args[])
		{
				int n;
			Scanner s=new Scanner(System.in);
			System.out.println("enter an integer");
			n=s.nextInt();
			run(n);
			
		}

	
}
