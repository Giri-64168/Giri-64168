import java.util.Scanner;
public class point
{
	double x;
	double y;
	point()
	{
		x=0;
		y=0;
	}
		
		point(double x1,double y1)
		{
			x=x1;
			y=y1;
		}
		public double distance_from_origin(point q)
		{

			double diff_x=x-q.x;
			double diff_y=y-q.x;
			return Math.sqrt(diff_x*diff_x+diff_y*diff_y);
		}
		public void translate(double x_trans,double y_trans)
		{
			x=x+x_trans;
			y=y+y_trans;
		}
		public static int result()
		{
			System.out.println(a);
			System.out.println(b);
			return a;
			return b;
		}
}
class test 
{
		public static void main(String args[])
		{
			Scanner s=new Scanner();
			System.out.println("enter the a value");
			double a=s.nextDouble();
			System.out.println("enter the b value");
			double b=s.nextDouble();
			point p=new point(a,b);
			p.distance_from_origin(a,b);
			p.translate(a,b);
			point.result();	
		}
}