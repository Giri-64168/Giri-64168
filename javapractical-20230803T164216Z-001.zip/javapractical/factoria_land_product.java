import java.util.Scanner;//find factorial and product of the given number 
 class factorial_and_product
{
	private int num;
	 public static int facto(int num)
	{
		int res=1;
		while(num>0)
		{
			if(num==0)
			{
				return res;
			}
			else 
			{
				res=res*num;
			}
			num--;
		}
		return res;
		
	}
	 public static int product(int num)
	{
		int pro=1;
		num=num%10;
		pro*=num;
		num=num/10;
		return pro;

	}

	public static void main(String[] args)
	{
    Scanner in = new Scanner(System.in);
    System.out.println("Enter the number: ");
    int num = in.nextInt();
    
    System.out.println("Factorial of "+num+" is "+facto(num));
 System.out.println("Factorial of "+num+" is "+product(num));
    	}
}
