import java.util.*;//finding area of triangle using class and constructors (data parts,methods)
class 	Box
{
	private double base;
	private double  height;

	public Box()
{
		base=height=0;
}
	public Box(double b,double h)
	{
		base=b;
		height=h;
	}
	 public double area_of_triangle()
	{
		double area=((1.0/2.0)*base*height);
		System.out.println("the area of the triangle using box method is  "+area);
		return area;
	}
}
  class area_of_triangle1
{
		public static void main(String args[ ])
		{
			Box a=new Box();
			Box b=new Box(5,5);
			a.area_of_triangle();
			b.area_of_triangle();
		}
}