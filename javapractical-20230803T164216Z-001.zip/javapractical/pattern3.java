import java.util.*;
class pattern3
{
		static void onerow(char c,int n)
		{
			for(int i=0;i<=n;i++)
			{
				System.out.print(c);
				
			}
				System.out.println(" ");
		}
		static void onecalm(int n,char c)
		{
			for(int i=n;i>0;i--)
			{
					onerow(c,i);
			}
		}
		static void printpattern(int n,char c)
		{
			for(int i=1;i<=n;i++)
				{
				onerow(c,i);
			
				}
			
		}
		public static void main(String args[ ])
		{
			int n=10;char ch='*';	
			if(n%2==0)
			{
				printpattern( n/2,ch);
				onecalm( n/2,ch);
			}
			else
			{
				printpattern( (int)n/2,ch);
				printpattern( (n+1)/2,ch);
			}	
			
			
		}
}