class Employee
{
	float sallary=40000;
	int bonus=30000;
}
class programmer extends Employee
{
	public static void main(String args[])
	{
		
		programmer e=new programmer();
		System.out.println("the sallary of a programmer is"+e.sallary);
		System.out.println("the bonus of a programmer is"+e.bonus);
	}
}