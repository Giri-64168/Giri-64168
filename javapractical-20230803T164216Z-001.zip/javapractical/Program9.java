import java.util.*;
class Program9
{
	
		static int diff(int a,int b)
		{return a-b;}
		static int product(int a,int b)
		{return a*b;}
		static int smallest(int a,int b)
		{
			if (a>b)return a;
			if (b<a)return b;
			return 0;
		}
		static int largest(int a,int b)
		{
			if(a>b)return a;
			if(b>a)return b;
			return 0;
		}
		public static void main(String args[])
		{

		Scanner s=new Scanner(System.in);
		int n1,n2,result;
		System.out.println("enter the first number");
		n1=s.nextInt();
		System.out.println("enter the SECOND NUMBER");
		n2=s.nextInt();
		result=diff(n1,n2);
		System.out.println("the diff of given two numbers is "+result);
		result=product(n1,n2);
		System.out.println("the product of given two numbers is "+result);	
		result=smallest(n1,n2);
		System.out.println("the smallest value of given two number"+result);
		result=largest(n1,n2);
		System.out.println("the largestst value of given two number"+result);
	}
}