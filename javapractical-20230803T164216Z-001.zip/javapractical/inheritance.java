class animal
{
	public void eat()
	{
		System.out.println("eating");
	}
}
class dog extends animal
{
	public void bark()
	{
		System.out.println("barking");
	}
}
class inheritance
{
	public static void main(String args[])
	{
		dog d=new dog();
		d.bark();
		d.eat();
	}
}