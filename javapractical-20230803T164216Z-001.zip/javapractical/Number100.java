import java.util.*;
class Number100
{
		public static void main(String args[])
		{
			Scanner s=new Scanner(System.in);
			int n,m;
			System.out.println("enter two integers");
			n=s.nextInt();
			m=s.nextInt();
			for(n=1;n<100;n++)
			{
				if((n%2)==0)
				break;
				
				System.out.println(n);
			}
			for(m=1;n<100;n++)
			{
				
				if((m%2)==0)
				break;
				System.out.println(m);
			}
			
		}
}