import java.util.*;
class greet
{
		public static void main(String args[ ])
		{
			char s;
			Scanner s=new Scanner(System.in);
			
			System.out.println("hii ");
			s1=s.nextChar();
			System.out.println("have a great day!!....i have so many works soo...byeee...");
		}
}