import java.util.*;//for using int
class Print
{
		public static void main(String args[ ])
		{
			int n;
			Scanner s=new Scanner(System.in);
			System.out.println("enter an integer");
			n=s.nextInt();
			for(int i=1;i<=n;i++)
			{
				
				System.out.println(i);
			}
		}
}