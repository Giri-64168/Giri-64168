import java.util.*;
class Program06
{
		public static void main(String args[])
		{
			int n,m,temp;
			Scanner s=new Scanner(System.in);
			System.out.println("eneter two integers");
			n=s.nextInt();			
			m=s.nextInt();
			n=(n+m)-(n=m);
			System.out.println("after swap the first value is  "+n);
			System.out.println("after swap the second value is  "+m);
		}
}