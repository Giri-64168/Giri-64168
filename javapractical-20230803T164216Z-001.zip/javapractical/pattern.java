import java.util.*;
class pattern
{
		public static void print_pattern(char ch,int n)
		{
			for(int i=0;i<n;i++)
			System.out.print(ch);
			System.out.println(" ");
		}
		public static void main(String args[ ])
		{
			
			print_pattern('#',1);
			print_pattern('#',2);
			print_pattern('#',3);
			print_pattern('#',4);
			print_pattern('#',5);
			
		}
}