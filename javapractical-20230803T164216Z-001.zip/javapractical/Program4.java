import java.util.*;
class Program4
{
	
			static boolean run(int n)
			{
				if(n%2==0)
				{return true;}
				else
				{return false;}
				
			} 
			public static void main(String args[])
		{
			Scanner s=new Scanner(System.in);
			int n;
			System.out.println("enter the element:");
			n=s.nextInt();
			if(run(n))
			{
				System.out.println(n+" is even number");

			}
			else
			{
				System.out.println(n+" IS ODD number");
				
			}
		}
}



