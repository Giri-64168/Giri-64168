import java.util.*;
class pattern1
{
		public static void print_pattern(char ch,int n)
		{
			for(int i=0;i<n;i++)
			System.out.print(ch);
			System.out.println(" ");
		}
		public static void main(String args[ ])
		{
			int nr=5;
			for(int i=1;i<=nr;i++)
			{
				print_pattern('#',i);
			}
			
			
		}
}