class author
{
  String author_name;
	int age;
	String place;
	author(String author_name,int age, String place)
	{
		this.author_name=author_name;
		this.age=age;
		this.place=place;
	}
}
class book
{
	String name;
	int price;
	author a;
	book(String name,int price,author a)
	{
		this.name=name;
		this.price=price;
		this.a=a;
	}
	public static void main(String args[])
	{
		author a=new author("john",42,"usa");
		book b=new book("java for bigenner",800,a);
		System.out.println("the book name is-- "+b.name);
		System.out.println(" the book price is-- "+b.price);
		System.out.println("------------author details-------");
		System.out.println("the author is-- "+a.author_name);
		System.out.println("age of the author is-- "+a.age);
		System.out.println(" place of the author is-- "+a.place);
	}
}
