import java.util.*;
class Program03
{
		static boolean isEven(int n)
		{
			boolean even_no=true;
			for(int i=1;i<=n;i++)
			even_no=!even_no;
			return even_no;
		}
		public static void main(String args[])
		{
			int n;
			Scanner s=new Scanner(System.in);
			System.out.println("enter an integer ");
			n=s.nextInt();
			if(isEven(n))
			System.out.println(" even ");
			else
			System.out.println("odd ");
		}
}