import java.util.*;
class test3
{
		public static void main(String args[ ])
		{
			Scanner s=new Scanner(System.in);
			mydate m=new mydate();
			m.set(2);
			m.month=2;
			m.year=2023;
			System.out.println(m.get()+"-"+m.month+"-"+m.year);
		}
}
class mydate
{
		private int day;
		public int month;
		public int year;
		public void set(int d)
		{
			day=d;
		}
		public int get()
		{
			return day;
		}
}