import java.util.*;
class Program8
{
	public static void main(String []args)
	{
		int num1,num2,diff,pro,smallest,largest;
		Scanner s=new Scanner(System.in);
		System.out.println("enter the first number");
		num1=s.nextInt();
		System.out.println("enter the second number");
		num2=s.nextInt();
		diff=num1-num2;
		pro=num1*num2;
		System.out.println("  the difference of given two numbers is   "+diff);
		System.out.println("  the product of given two numbers is   "+pro);
		if(num1>num2 && num2<num1)
		{
			System.out.println("  num1 is larger ");
		
		}
		else if(num1==num2)
		{
			System.out.println("  both are equal ");
		}	
		else 
		{
			System.out.println("  num2 is larger ");
		}
		
	}
}