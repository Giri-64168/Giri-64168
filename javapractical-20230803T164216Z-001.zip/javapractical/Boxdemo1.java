import java.util.*;//DATA PART AND METRHOD PART IN CLASS
class Box
{
	private double depth;
	private double width;
	private double height;
  public   Box()
{
		width=depth=height=0.0;
		
}

public   Box(double d,double w,double h)
{
	depth=d;
	width=w;
	height=h;
	
}
		public void volume()
   {
	System.out.println("volume is   "+(depth*width*height));
		
    }
}

class Boxdemo1
{
		public static void main(String args[] )
		{
			Box b=new Box();
			Box a=new Box(10,20,30);
			b.volume();
			a.volume();
			

		}
}