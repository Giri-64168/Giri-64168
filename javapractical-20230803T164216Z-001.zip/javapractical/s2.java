class s1
{
	static int x;static int y;
	void add(int a,int b)
	{
		x=a+b;  y=x+b;
	}
}
class s2
{
	public static void main(String args[])
	{
		s1 s=new s1();
		s1 s3=new s1();
		int a=2;
		s.add(a,a+1);
		s3.add(5,a);
		System.out.println(s.x+""+s.y);
	}
}