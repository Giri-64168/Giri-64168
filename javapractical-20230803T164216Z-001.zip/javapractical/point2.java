public class triangle
{
	point p;
	point q;
	point r;
	public point getp()
	{
		return this.p;
	}
	public point getq()
	{
		
		return this.q;
	}
	public point getr()
	{
		
		return this.r;
	}
	public triangle(point A, point B,point C)
	{
		this.p=new point( A.x,A.y)
		this.q=new point( B.x,B.y)
		this.r=new point( C.x,C.y)
	}
`	Public triangle(  double x1,double y1,double x2,double y2,double x3,double y3 )
	{
		this.p=new point(x1,y1);
		this.q=new point(x2,y2);
		this.r=new point(x3,y3);
	}
	public double perimeter()
	{
		double peri;
		peri=this.p.distance_from_point(this.q);
		peri=peri+this.p.distance_from_point(this.p);
		peri=peri+this.q.distance_from_point(this.r);
		return peri;
	}
	public void translate(double x_trans,double y_trans)
	{
		this.p.translate(x_trans,y_trans);
		this.q.translate(x_trans,y_trans);
		this.r.translate(x_trans,y_trans);
	}
	public double area()
	{
		double peri,area,s,a,b,c;
		peri=this.perimeter();
		s=peri/2;
		a=this.p.distance_from_point(this.q);
		b=this.p.distance_from_point(this.r);
		c=this.q.distance_from_point(this.r);
		area=Math.sqrt(s*(s-a)*(s-b)*(s-c));
		return area;
	}
}