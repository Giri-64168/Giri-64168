import java.util.*;
class pattern
{
		static void print_pattern(char ch,int n);
		{
			for(k=0;k<n;k++)
			System.out.println(ch);
			System.out.println("\n");
		}
		public static void main(String args[ ])
		{
			print_pattern('#',1);
			print_pattern('#',2);
			print_pattern('#',3);
			print_pattern('#',4);
			print_pattern('#',5);
			
		}
}