import java.util.*;
class Number701
{
	
	private int n;
	public void set(int n)
	{
		this.n=n;
	}
	public int get()
	{
		return n;
	}
	public static int sumdigit(int n)
	{
		this.n=n;
		int sum=0;
		while(n>0)
		{	
		sum=(sum+(n%10));
		n=n/10;	
		}
		return sum;
	}
	public static void main(String args[])
	{
	number n=new number();
	Scanner s=new Scanner(System.in);
	System.out.println("enter a number");
	int t=s.nextInt();
	System.out.println("the sum of the digits of the given numer"+sumdigit(t));
	}
	
}