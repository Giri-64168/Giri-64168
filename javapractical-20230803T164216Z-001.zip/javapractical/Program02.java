import java.util.*;
class Program02
{
		static int isEven(int n)
		{
			return(n & 1);
		}
		public static void main(String args[])
		{
			int n;
			Scanner s=new Scanner(System.in);
			System.out.println("enter an integer ");
			n=s.nextInt();
			if(isEven(n)==0)
			System.out.println("is even");
			else 
			System.out.println("is odd");
			
		}
}