
import java.util.*;//about classusing methods and data part
class Box
{
	double d;
	double w;
	double h;
}
class Boxdemo
{
		public static void main(String args[] )
		{
			Box b=new Box();
			b.d=10;
			b.w=20;
			b.h=30;
			double v=b.d*b.w*b.h;
			System.out.println("the volumeis "+v);
		}
}