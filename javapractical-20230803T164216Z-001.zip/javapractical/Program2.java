import java.util.*;
class Program2
{
	
			static boolean run(int n)
			{
				return((n/2)*2==n);
			} 
			public static void main(String args[])
		{
			Scanner s=new Scanner(System.in);
			int n;
			System.out.println("enter the element:");
			n=s.nextInt();
			if(run(n))
			{
				System.out.println(n+" is even number");

			}
			else
			{
				System.out.println(n+" IS ODD number");
				
			}
		}
}



