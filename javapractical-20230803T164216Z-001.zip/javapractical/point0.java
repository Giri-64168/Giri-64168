public class point0
{
	double x;
	double y;
	point0()
	{
		x=0;
		y=0;
	}
		
		point0(double x1,double y1)
		{
			x=x1;
			y=y1;
		}
		public double distance_from_point(point q)
		{
			
			
		}
		public double distance_from_origin()
		{
			double diff_x=x-q.x;
			double diff_y=y-q.x;
			return Math.sqrt(diff_x*diff_x+diff_y*diff_y);
		}
		public void translate(double x_trans,double y_trans)
		{
			x=x+x_trans;
			y=y+y_trans;
		}
}