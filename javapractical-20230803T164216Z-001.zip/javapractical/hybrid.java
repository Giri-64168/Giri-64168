class a
{
	void disp_a()
	{
		System.out.println("method of class a");
	}
}
class b extends a 
{
	void disp_b()
	{
		System.out.println("method of class b");
	}
}
class c extends a
{
	void disp_c()
	{
		System.out.println("method of class c");
	}
}
class hybrid extends b
{
	void disp_d()
	{
		System.out.println("method of class d");
	}
	public static void main(String args[])
	{
	hybrid f=new hybrid();
	f.disp_a();
	f.disp_d();
	f.disp_b();
	c r=new c();
	r.disp_c();
	r.disp_a();
	}
}