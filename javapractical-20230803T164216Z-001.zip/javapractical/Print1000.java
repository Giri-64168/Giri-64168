import java.util.*;
class Print1000
{
		public static void main(String args[ ])
		{
			int sum=0;
			int n=1000;
			Scanner s=new Scanner(System.in);
			for(int i=1;i<=n;i++)
			{
				sum+=i;
			}
			System.out.println("sum is  "+sum);
		}
}