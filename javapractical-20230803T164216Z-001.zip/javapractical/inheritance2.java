class animal
{
	public void eat()
	{
		System.out.println("eating");
	}
}
class dog extends animal
{
	public void bark()
	{
		System.out.println("barking");
	}
}
class babydog extends dog
{
	public void weep()
	{
	System.out.println("weeping");
	}
}
class inheritance2
{
	public static void main(String args[])
	{
	babydog b=new babydog();
	b.eat();
	b.weep();
	b.bark();
	}
}