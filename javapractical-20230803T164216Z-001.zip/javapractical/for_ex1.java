import java.util.*;//understand while and for also
class for_ex1
{
		public static void main(String args[] )
		{
			Scanner s=new Scanner(System.in);
			for( int count=1;count<10;count++)
			{
				System.out.println("hello");
			}
			while(true)
			{
				System.out.println("hii");
			}
		}
}