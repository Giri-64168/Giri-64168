import java.util.*;//printing byte range upto
class Print5
{
		public static void main(String args[ ])
		{
			
			Scanner s=new Scanner(System.in);
			for(byte i=1;i<=10;--i)
			{
				System.out.println("hello"+i);
			}
		}
}